#!/bin/bash
clear
echo $1 >> /tmp/aio.log
#source
LOCA=/etc/aio/aiorun 
source $LOCA/tags
source $LOCA/messages
source $LOCA/librarys
source $LOCA/list
source $LOCA/build
source $LOCA/install
source $LOCA/store
source $LOCA/store-settings
source $LOCA/store-tags
source $JAR/aio.lang
source $JAR/aio.thm
#if [ -f "~/.config/aio.conf" ]; then troca=troca; else echo "anistore='1'" > ~/.config/aio.conf; chmod +x ~/.config/aio.conf;fi
if [ "$DevMODE" == "" ]; then DevMODE="0"; fi
source ~/.config/aio.conf
#CORRECTION
if [ -e "/etc/aio/aio.list" ]; then mkdir $REGs; mv $JAR/aio.list $REGs; fi

case "$(uname -i)" in
  x86_64|amd64)
#    echo "x86-64 system architecture"
    SYSTEM_ARCH="x86_64";;
  i?86)
#    echo "x86 system architecture"
    SYSTEM_ARCH="i686";;
  aarch64|arm64)
#    echo "ARM system architecture"
    SYSTEM_ARCH="aarch64";;
  unknown|AuthenticAMD|GenuineIntel)
#         uname -i not answer on debian, then:
    case "$(uname -m)" in
      x86_64|amd64)
#        echo "x86-64 system architecture"
        SYSTEM_ARCH="x86_64";;
      i?86)
#        echo "x86 system architecture"
        SYSTEM_ARCH="i686";;
      aarch64|arm64)
#        echo "ARM system architecture"
        SYSTEM_ARCH="arm64";;
    esac ;;
  *)
    echo "Unsupported system architecture, testing if ARM"
    exit 1;;
esac

echo $1 $2 $3 $4 $5




##########################################
##
##				LAUNCHERS
##
##########################################

ISONLINE=`service NetworkManager status | grep "manager:" | awk '/D*G/{print $13}'`
GETMIND
#if [ "$ISONLINE" == "CONNECTED_GLOBAL" ]; then 
#### COMANDOS E INTEGRAÇÔES
if [[ "`whoami`" == "root" ]]; then echo "Os comandos só são executados sem a conta de Administrador"; if  [ "$1" == "f-i" ]; then INSTALLAIO; fi else

 if [[ "$1" == "add" || "$1" == "install" || "$1" == "-a" ]]; then
  STORER="$2"
  GETNETBOOK
  GETICONAPP
  CHECKAIOVERSION
  InNAME=$2
  PageName=`echo $InNAME | tr '[:upper:]' '[:lower:]'`
  echo -ne "" > $JAR/aiostore/$PageName.html
  TESTLOCAL
  if [ "$PROGRESS" == "1" ]; then NATIVEFIER; fi
  if [ "$PROGRESS" == "1" ]; then GETONLY; fi
  if [[ "$3" == "-mb" || "$4" == "-mb" ]]; then echo "A Bases serão mantidas"; else if [ "$PROGRESS" == "1" ]; then DELOVEN; fi fi
  if [ "$PROGRESS" == "1" ]; then MOVEAPP; fi
  MOUNTLISTS
  
 
 elif [[ "$1" == "del" || "$1" == "remove" || "$1" == "-d" ]]; then
  GETNETBOOK
  CHECKAIOVERSION
  InNAME=$2
  PageName=`echo $InNAME | tr '[:upper:]' '[:lower:]'`
  echo -ne "" > $JAR/aiostore/$PageName.html
  DEL
  MOUNTLISTS

  
 elif [[ "$1" == "uninstallaio" || "$1" == "aio:uninstallaio" ]]; then
  GETNETBOOK
  CHECKAIOVERSION
  sudo rm -Rf /home/APPS && rm /usr/bin/aio && rm -Rf /usr/bin/pkg2appimage && rm -Rf /usr/bin/wai && rm -Rf /usr/share/aio.desktop && rm -Rf /etc/aio

 elif [[ "$1" == "info" || "$1" == "-i" ]]; then
  CHECKAIOVERSION
  InNAME=$2
  INFOAPP

 elif [[ "$1" == "list" || "$1" == "-l" ]]; then
  GETNETBOOK
  LISTJAR
  CHECKAIOVERSION
  
 elif [[ "$1" == "mkrecipe" || "$1" == "-m" ]]; then
  GETNETBOOK
  CHECKAIOVERSION
  LUGAR=`pwd`
  AppMake=$2
  echo "make a generic recipe, baseed in Input name"
  echo "app: "$AppMake"
binpatch: true

ingredients:
  dist: focal
  package: "$AppMake"
#  release:
#    - libera os pacotes que estão na blacklist
  sources:
    - deb http://archive.ubuntu.com/ubuntu focal main universe
    - deb http://security.ubuntu.com/ubuntu focal-security main universe
#  ppas:
#    - 
#  script:
#    - Preparação dos ingredientes

#script:
#  - Para alocação dentro do Appimage." > $LUGAR/$AppMake.yml
 
 elif [[ "$1" == "upd" || "$1" == "update" || "$1" == "-u" ]]; then
  GETNETBOOK
  CHECKAIOVERSION
  InNAME=$2
  PageName=`echo $InNAME | tr '[:upper:]' '[:lower:]'`
  echo -ne "" > $JAR/aiostore/$PageName.html
  CALLLOCAL
  DEL
  echo "Atualizando: "$ITEMW
  TESTLOCAL
#  NATIVEFIER
  if [ "$PROGRESS" == "1" ]; then GETONLY; fi
  if [[ "$3" == "-mb" || "$4" == "-mb" ]]; then echo "A Bases serão mantidas"; else if [ "$PROGRESS" == "1" ]; then DELOVEN; fi fi
  if [ "$PROGRESS" == "1" ]; then MOVEAPP; fi


 elif [[ "$1" == "--help" || "$2" == "--help" || "$3" == "--help" || "$4" == "--help" || "$1" == "help" || "$2" == "help" || "$3" == "help" || "$4" == "help" ]]; then
  HELP

 elif [[ "$1" == "store" ]]; then
  if [[ "$3" == "-r" || "$4" == "-r" ]]; then
   GETNETBOOK
   CHECKAIOVERSION
   CKWEBSERVER
   MOUNTLISTS
   MOUNTPAGE
  else
   RUNPAGE
   GETNETBOOK
   CHECKAIOVERSION
  fi

 elif [[ "$1" == "aio:store-up" || "$1" == "upstore" || "$1" == "storeup"  || "$1" == "update-store" ]]; then
  echo "*" > $JAR/aiostore/aiostore.html
  if [[ $DevMODE == "1" ]]; then echo "Devmode:"$DevMODE >> /tmp/aio.log;  MSGUS001; else echo "Devmode:"$DevMODE >> /tmp/aio.log; fi
#  echo $JsReload$ShReload >> $JAR/aiostore/index.html
  GETNETBOOK
  echo "*" >> $JAR/aiostore/aiostore.html
  CKWEBSERVER
  echo "*" >> $JAR/aiostore/aiostore.html
  CONVTHMCSS
  MOUNTLISTS
  NEWNESS
  MOUNTPAGE
  CHECKAIOVERSION
  sleep 2
  rm $JAR/aiostore/aiostore.html

 elif  [[ "$1" == "f-i" ]]; then echo "Vamos instalar... Execute como Root:
$ sudo ./aio";

##Fim dos comandos por texto
 fi
fi


if [ -e "$JAR" ]; then troca=troca; else 
 if [ "`whoami`" == "root" ]; then echo 'iniciando instalacao'; INSTALLAIO; else echo "Vamos instalar... Execute como Root:
$ sudo ./aio"; fi fi	#Aciona a instalacao
