#!/bin/bash
clear
echo $1 >> /tmp/aio.log
JAR=/etc/aio	#Pasta das definições
LOCA=$JAR/aiorun 
source $LOCA/tags
source $LOCA/messages
source $LOCA/librarys
source $LOCA/list
source $LOCA/build
source $LOCA/install
source $LOCA/store
source $LOCA/store-settings
source $LOCA/store-tags
source $LOCA/mkrecipe
source $JAR/aio.lang
source $JAR/aio.thm

#if [ -f "~/.config/aio.conf" ]; then troca=troca; else echo "anistore='1'" > ~/.config/aio.conf; chmod +x ~/.config/aio.conf;fi
if [ "$DevMODE" == "" ]; then DevMODE="0"; fi
source ~/.config/aio.conf
#CORRECTION
if [ -e "/etc/aio/aio.list" ]; then mkdir $REGs; mv $JAR/aio.list $REGs; fi

case "$(uname -i)" in
  x86_64|amd64)
#    echo "x86-64 system architecture"
    SYSTEM_ARCH="x86_64";;
  i?86)
#    echo "x86 system architecture"
    SYSTEM_ARCH="i686";;
  aarch64|arm64)
#    echo "ARM system architecture"
    SYSTEM_ARCH="aarch64";;
  unknown|AuthenticAMD|GenuineIntel)
#         uname -i not answer on debian, then:
    case "$(uname -m)" in
      x86_64|amd64)
#        echo "x86-64 system architecture"
        SYSTEM_ARCH="x86_64";;
      i?86)
#        echo "x86 system architecture"
        SYSTEM_ARCH="i686";;
      aarch64|arm64)
#        echo "ARM system architecture"
        SYSTEM_ARCH="arm64";;
    esac ;;
  *)
    echo "Unsupported system architecture, testing if ARM"
    exit 1;;
esac

#echo $*; inmain=$*

##########################################
##
##				LAUNCHERS
##
##########################################
if [[ "$BOOK" == '' ]]; then GETNETBOOK; fi
ISONLINE=`ping -c 1 8.8.8.8 > /dev/null && echo 'true'`
GETMIND
#if [ "$ISONLINE" == "CONNECTED_GLOBAL" ]; then 
#### COMANDOS E INTEGRAÇÔES
if [[ "$1" == "" ]]; then echo "A Entrada está vasia, tente com algum comando"; if [ -e "$JAR" ]; then troca=troca; else pkexec STARTINSTALL; fi	#Aciona a instalacao
else
 if [[ "`whoami`" == "root" ]]; then echo "Os comandos só são executados sem a conta de Administrador"; if  [ "$1" == "f-i" ]; then INSTALLAIO; fi else
  cloja=`echo $1 | sed -e 's|\%20| |g'`
  echo $cloja >> /tmp/aio.log
  STOREC=`echo $cloja | awk '{print $1}'`
  STORER=`echo $cloja | awk '{print $2}'`
 
 if [[ "$1" == "add" || "$1" == "install" || "$1" == "-a" || "$STOREC" == "aio:add" ]]; then
  if [[ "$STORER" == '' ]];then InNAME=$2; STORER=$2; else InNAME=$STORER; fi
  TENT=$(echo "$BOOK" | grep $InNAME: | awk '{print $1}' | sed "s/://g")
  if [[ "$TENT" == "$InNAME" ]]; then
   PageName=`echo $InNAME | tr '[:upper:]' '[:lower:]'`; echo -ne "" > $JAR/aiostore/$PageName.html
   Fname=`echo "$BOOK" | grep -w "$TENT:" | awk '{print $5}' | sed 's/&nbsp;/ /g'`; echo "Instalando: "$Fname
   GETICONAPP; notify-send --icon="/tmp/icon-$STORER/icon.png" "Instalando: $Fname";
   COOK
   INTEGRATE
   echo "******************** BUILD COMPLETE **********************"
   MOUNTPAGE
   notify-send --icon="/tmp/icon-$STORER/icon.png" "$Fname Instalado";
   rm -Rf /tmp/icon-$InNAME;
  else
   echo "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
 Só posso Instalar apps que estão listados
	Por favor tente um nome diferente
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
  fi 
 
 elif [[ "$1" == "del" || "$1" == "remove" || "$1" == "-d" || "$STOREC" == "aio:del" ]]; then
  if [[ "$STORER" == '' ]];then InNAME=$2; STORER=$2; else InNAME=$STORER; fi
  TENT=$(echo "$INSTALLED" | grep $InNAME: | awk '{print $1}' | sed "s/://g")
  if [[ "$TENT" == "$InNAME" ]]; then
  PageName=`echo $InNAME | tr '[:upper:]' '[:lower:]'`;  echo -ne "" > $JAR/aiostore/$PageName.html
  Fname=`echo "$BOOK" | grep -w "$InNAME:" | awk '{print $5}' | sed 's/&nbsp;/ /g'`; echo "Removendo: "$Fname
  GETICONAPP; notify-send --icon="/tmp/icon-$STORER/icon.png" "Removendo: $Fname";
  DELETEAPP
  echo "******************** BUILD COMPLETE **********************"
  MOUNTPAGE
  if [[ "$DevMODE" == "1" ]]; then notify-send --icon="/tmp/icon-$STORER/icon.png" "Removido: $Fname"; fi
  rm -Rf /tmp/icon-$InNAME;
  else
  echo "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
 Só posso Remover apps que estão instalados
	Por favor tente um nome diferente
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
 fi
 
 elif [[ "$1" == "upd" || "$1" == "update" || "$1" == "-u" || "$STOREC" == "aio:upd" ]]; then
  if [[ "$STORER" == '' ]];then InNAME=$2; STORER=$2; else InNAME=$STORER; fi
  TENT=$(echo "$INSTALLED" | grep $InNAME: | awk '{print $1}' | sed "s/://g" | tail -n 1)
  if [[ "$TENT" == "$InNAME" && "$InNAME" != '' ]]; then
   PageName=`echo $InNAME | tr '[:upper:]' '[:lower:]'`; echo -ne "" > $JAR/aiostore/$PageName.html
   Fname=`echo "$BOOK" | grep -w "$InNAME:" | awk '{print $5}' | sed 's/&nbsp;/ /g'`; echo "Atualizando: "$Fname
   GETICONAPP; sleep 1.5; notify-send --icon="/tmp/icon-$STORER/icon.png" "Atualizando: $Fname";
   DELETEAPP
   if [[ "$DevMODE" == "1" ]]; then notify-send --icon="/tmp/icon-$STORER/icon.png" "Removido: $Fname"; fi
   COOK
   INTEGRATE
   echo "******************** BUILD COMPLETE **********************"
   MOUNTPAGE
   if [[ "$DevMODE" == "1" ]]; then notify-send --icon="/tmp/icon-$STORER/icon.png" "$Fname Atualizado"; fi
   rm -Rf /tmp/icon-$InNAME;
  else
   if [[  "$2" -ne '' ]]; then GETNETBOOK;  CHECKAIOVERSION; else
    echo "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
 Só posso Atualizar apps que estão instalados
	Por favor tente um nome diferente
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"; fi
  fi 
  
 elif [[ "$1" == "uninstallaio" || "$1" == "aio:uninstallaio" ]]; then
  notify-send -i /etc/aio/aio-store.svg "Removendo: AIO Store";
  if [[ "$rmapps" == "1" ]]; then pkexec sudo rm -Rf /home/APPS && sudo rm /usr/bin/aio && sudo rm -Rf /usr/bin/pkg2appimage && sudo rm -Rf /usr/bin/wai && sudo rm -Rf /usr/share/aio.desktop && sudo rm -Rf /etc/aio;
  else pkexec sudo rm /usr/bin/aio && sudo rm -Rf /usr/bin/pkg2appimage && sudo rm -Rf /usr/bin/wai && sudo rm -Rf /usr/share/aio.desktop && sudo rm -Rf /etc/aio;
  fi
  notify-send -i /etc/aio/aio-store.svg "AIO Store Removida"; echo "AIO Removida";

 elif [[ "$1" == "info" || "$1" == "-i" || "$1" == "show" ]]; then
  InNAME=$2
  if [[ "$2" == "all" ]]; then INFOALL; else INFOAPP; fi

 elif [[ "$1" == "list" || "$1" == "-l" ]]; then
  LISTCOOKIES

 elif [[ "$1" == "-s" ]]; then
	InNAME=$2;SEARCHCOOKIE
	echo "APT: "$2
	apt search $2
  
 elif [[ "$1" == "mkrecipe" || "$1" == "-m" ]]; then
  InNAME=$2
  if [[ "$InNAME" == '' || "$InNAME" == ' ' ]]; then echo "Coloque pelo o menos um nome"; else
    if [[ $* == *" -add"* ]]; then listpackages=$*; addpackages; fi
    if [[ $* == *" -exclude"* ]]; then listrmpackages=$*; exclpackages; fi
    if [[ $* == *" -name"* ]]; then echo $* > /tmp/infoname;infoname=$(cat /tmp/infoname | awk -F ' -name ' '{print $2}' | awk -F ' -' '{print $1}' ); reponame; else infoname='focal'; fi
    if [[ $* == *" -nitrux"* ]]; then inforepo=$*; reponitrux; fi
    if [[ $* == *" -mint"* ]]; then inforepo=$*; repomint; fi
    if [[ $* == *" -neon"* ]]; then inforepo=$*; reponeon; fi
    if [[ $* == *" -pop"* ]]; then inforepo=$*; repopop; fi
    if [[ $* == *" -elementary"* ]]; then inforepo=$*; repoelementary; fi
    if [[ $* == *" -deepin"* ]]; then inforepo=$*; repodeepin; fi
    if [[ $* == *" -ppa"* ]]; then infoppa=$*; repoppa; fi
    if [[ $* == *" -github"* ]]; then inforepo=$*; repogithub; fi
    if [[ $* == *" -sourceforge"* ]]; then inforepo=$*; reposourceforge; fi
    if [[ $* == *" -qt"* ]]; then releaseqt; fi
    if [[ $* == *" -release"* ]]; then inrelease=$*; reciperelease; fi
    if [[ $* == *" -ingredient"* ]]; then inbd=$*; recipepre; fi
    if [[ $* == *" -script"* ]]; then inbd=$*; recipeshbody; fi
    if [[ $* == *" -nir"* ]]; then NIR="
    - --no-install-recommends"; fi
    MKRECIPE
    cat $InNAME.yml
    if [[ $* == *" -xt"*  ]]; then rm -Rf $InNAME && r2a $InNAME.yml; rm $JAR/aiostore/$InNAME.html; fi
  fi
  
 elif [[  $* == *" -xt"*  ]]; then
   OVEN=$1; OVEN=$($OVEN | sed 's/.yml//g');
   if [ -f $OVEN ]; then rm -Rf $OVEN; else echo $OVEN; fi
   r2a $1; if [ -f $JAR/aiostore/$OVEN.html ]; then rm $JAR/aiostore/$OVEN.html; fi

 elif [[ "$1" == "--help" || "$2" == "--help" || "$3" == "--help" || "$4" == "--help" || "$1" == "help" || "$2" == "help" || "$3" == "help" || "$4" == "help" ]]; then
  HELP

 elif [[ "$1" == "store" ]]; then
  GETNETBOOK
  CHECKAIOVERSION
  if [[ "$3" == "-r" || "$4" == "-r" ]]; then 
   if [[ "$UPGRADE" == '1' ]]; then aio store -r; else CKWEBSERVER; MOUNTPAGE; fi
  else
   if [[ "$UPGRADE" == '1' ]]; then aio store; else RUNPAGE; fi
  fi

 elif [[ "$1" == "aio:store-up" || "$1" == "upstore" || "$1" == "storeup"  || "$1" == "update-store" ]]; then
  echo "" > $JAR/aiostore/aiostore.html
  GETNETBOOK
  CHECKAIOVERSION
  if [[ "$UPGRADE" == '1' ]]; then aio upstore; else
	echo "*" >> $JAR/aiostore/aiostore.html
	GETLISTS
	if [[ "$DevMODE" == "1" ]]; then echo "Devmode:"$DevMODE >> /tmp/aio.log; notify-send -i /etc/aio/aio-store.svg "Atualizando a Loja"; fi
	CKWEBSERVER; echo "*" >> $JAR/aiostore/aiostore.html
	CONVTHMCSS; echo "*" >> $JAR/aiostore/aiostore.html
	MOUNTPAGE
	sleep 2
	rm $JAR/aiostore/aiostore.html
  fi

 elif  [[ "$1" == "f-i" ]]; then echo "Vamos instalar... Execute como Root:
$ sudo ./aio";
 fi
 fi
fi
