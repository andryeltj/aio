#!/bin/bash
PLACE=`pwd`
USeR=$(echo $USER)
if [[ $* == *"-remove"*  ]]; then
  sudo umount /media/$USeR/LinuxCD && sudo umount /mnt && rm -Rf /media/$USeR/LinuxCD
else
  sudo mkdir /media/$USeR/LinuxCD && sudo chmod -R 555 /media/$USeR/LinuxCD
  sudo mount -o loop $1 /mnt
  sudo mount /mnt/casper/filesystem.squashfs /media/$USeR/LinuxCD -t squashfs -o loop
fi
